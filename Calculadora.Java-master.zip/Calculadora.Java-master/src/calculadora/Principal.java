package calculadora;
import GUI20.GUI;
import java.util.Scanner;
import calculadora.logica.CalculadoraDecimal;
public class Principal{
    public static void main(String[] args) {
//       CalculadoraDecimal calculadora=new CalculadoraDecimal();
//       Scanner sc = new Scanner(System.in);
//        System.out.println("Ingrese Operando 1 ");
//        calculadora.setOperando1(sc.nextInt());
//        System.out.println("Ingrese Operando 2 ");
//        calculadora.setOperando2(sc.nextInt());
//        calculadora.sumar();
//        System.out.println(calculadora.getresultado());
//        calculadora.restar();
//        System.out.println(calculadora.getresultado());
//        calculadora.multiplicar();
//        System.out.println(calculadora.getresultado());
//        calculadora.dividir();
//        System.out.println(calculadora.getresultado());
    
    
  
    
    }
}
        
        
          